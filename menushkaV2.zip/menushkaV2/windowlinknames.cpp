#include "windowlinknames.h"

WindowLinkNames::WindowLinkNames()
{

}
