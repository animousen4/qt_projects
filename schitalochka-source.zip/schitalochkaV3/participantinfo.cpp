#include "participantinfo.h"

ParticipantInfo::ParticipantInfo(QString _studentName, QString _imageFileName) : studentName(_studentName), imageFileName(_imageFileName)
{

}

ParticipantInfo::ParticipantInfo() {

}
